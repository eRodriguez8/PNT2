module.exports = {
    secret: 'ksajfhO/#Q$OBOAHONUFHos3j7y59'
};